import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>Contacto</h2>
      {/* Contenido adicional de la página de contacto */}
    </div>
  );
}

export default Contact;