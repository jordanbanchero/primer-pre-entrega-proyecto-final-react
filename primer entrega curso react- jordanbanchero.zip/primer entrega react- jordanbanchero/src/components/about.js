import React from 'react';

const About = () => {
  return (
    <div>
      <h2>Acerca de</h2>
      {/* Contenido adicional de la página "Acerca de" */}
    </div>
  );
}

export default About;